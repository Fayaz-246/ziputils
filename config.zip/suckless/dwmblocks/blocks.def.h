//Modify this file to change what commands output to your statusbar, and recompile using the make command.
static const Block blocks[] = {
	/*Icon*/	/*Command*/		/*Update Interval*/	/*Update Signal*/
  //  {" ", "kernel", 6000, 0},
  {" ",    "upt",        60,                 0 },
  {"  ",   "vol",        0,                 10 },
  {" ",    "mem",        60,                 0 },
  {"󰅐 ",    "clock",      60,                 0 },
  {"󱟢 ",    "bat",        60,                 0 },
};

//sets delimiter between status commands. NULL character ('\0') means no delimiter.
static char delim[] = " / ";
static unsigned int delimLen = 5;
